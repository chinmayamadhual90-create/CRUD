CREATE DATABASE ecommerce_db;
USE ecommerce_db;

CREATE TABLE users (...);
-- truncated for brevity in this summary
